<?php
/**
 * Homepage components, blocks, and community map.
 *
 * @package ADAM_Comunidade
 */

namespace ADAM\Comunidade\Directory;

defined( 'ABSPATH' ) || exit;

use ADAM\Comunidade\Fields\Repository as Field_Repository;
use ADAM\Comunidade\Fields\Router as Field_Router;
use ADAM\Comunidade\Helpers;
use ADAM\Comunidade\Placeholder_Image;
use ADAM\Comunidade\Teams\Repository as Team_Repository;
use ADAM\Comunidade\Teams\Router as Team_Router;
use ADAM\Comunidade\Teams\View as Team_View;

/**
 * Provides reusable, server-rendered homepage building blocks.
 */
final class Components {
	public function __construct(
		private Repository $repository,
		private Relationship_Repository $relationships
	) {}

	public function register(): void {
		add_action( 'adam_comunidade_register_shortcodes', array( $this, 'register_shortcodes' ) );
		add_action( 'init', array( $this, 'register_blocks' ), 20 );
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue_assets' ), 25 );
		add_action( 'adam_comunidade_team_after_content', array( $this, 'team_connections' ) );
		add_action( 'adam_comunidade_field_after_content', array( $this, 'field_connections' ) );
		add_filter( 'the_content', array( $this, 'community_map_content' ), 12 );
	}

	public function register_shortcodes(): void {
		add_shortcode( 'adam_featured_partner', fn( array $attributes = array() ): string => $this->highlight( 'partner', 'featured' ) );
		add_shortcode( 'adam_newest_partner', fn( array $attributes = array() ): string => $this->highlight( 'partner', 'newest' ) );
		add_shortcode( 'adam_featured_brand', fn( array $attributes = array() ): string => $this->highlight( 'partner', 'featured', 'brand' ) );
		add_shortcode( 'adam_institution_spotlight', fn( array $attributes = array() ): string => $this->highlight( 'institution', 'featured' ) );
		add_shortcode( 'adam_random_partner', fn( array $attributes = array() ): string => $this->highlight( 'partner', 'random' ) );
		add_shortcode( 'adam_community_section', array( $this, 'section_shortcode' ) );
		add_shortcode( 'adam_community_map', fn( array $attributes = array() ): string => $this->map() );
	}

	/**
	 * Loads component assets only on routes or posts that can render them.
	 *
	 * @return void
	 */
	public function maybe_enqueue_assets(): void {
		global $post;
		$content = $post instanceof \WP_Post ? $post->post_content : '';
		$community = \ADAM\Comunidade\Managed_Pages::is_current( 'community' );
		$has_component = $community || (bool) get_query_var( 'adam_team_slug' )
			|| (bool) get_query_var( 'adam_field_slug' )
			|| str_contains( $content, '[adam_' )
			|| has_block( 'adam-comunidade/community-section', $content )
			|| has_block( 'adam-comunidade/community-highlight', $content )
			|| has_block( 'adam-comunidade/community-map', $content );
		if ( $has_component ) {
			$has_map = $community || str_contains( $content, '[adam_community_map' ) || has_block( 'adam-comunidade/community-map', $content );
			$this->assets( $has_map );
		}
	}

	public function register_blocks(): void {
		wp_register_script(
			'adam-comunidade-blocks',
			Helpers::url( 'assets/js/community-blocks.js' ),
			array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-i18n' ),
			ADAM_COMUNIDADE_VERSION,
			true
		);
		register_block_type(
			'adam-comunidade/community-section',
			array(
				'api_version'   => 3,
				'editor_script' => 'adam-comunidade-blocks',
				'attributes'    => array(
					'type'     => array( 'type' => 'string', 'default' => 'teams' ),
					'number'   => array( 'type' => 'number', 'default' => 6 ),
					'order'    => array( 'type' => 'string', 'default' => 'newest' ),
					'category' => array( 'type' => 'string', 'default' => '' ),
					'featured' => array( 'type' => 'boolean', 'default' => false ),
				),
				'render_callback' => fn( array $attributes ): string => $this->section( $attributes ),
			)
		);
		register_block_type(
			'adam-comunidade/community-highlight',
			array(
				'api_version'   => 3,
				'editor_script' => 'adam-comunidade-blocks',
				'attributes'    => array(
					'type' => array( 'type' => 'string', 'default' => 'featured_partner' ),
				),
				'render_callback' => function ( array $attributes ): string {
					$types = array(
						'featured_partner'      => array( 'partner', 'featured' ),
						'newest_partner'        => array( 'partner', 'newest' ),
						'random_partner'        => array( 'partner', 'random' ),
						'featured_brand'        => array( 'partner', 'featured', 'brand' ),
						'institution_spotlight' => array( 'institution', 'featured' ),
					);
					$choice = $types[ $attributes['type'] ?? '' ] ?? $types['featured_partner'];
					return $this->highlight( $choice[0], $choice[1], $choice[2] ?? '' );
				},
			)
		);
		register_block_type(
			'adam-comunidade/community-map',
			array(
				'api_version'     => 3,
				'editor_script'   => 'adam-comunidade-blocks',
				'render_callback' => fn(): string => $this->map(),
			)
		);
	}

	public function section_shortcode( array $attributes = array() ): string {
		return $this->section(
			shortcode_atts(
				array( 'type' => 'teams', 'number' => 6, 'order' => 'newest', 'category' => '', 'featured' => false ),
				$attributes,
				'adam_community_section'
			)
		);
	}

	/**
	 * Renders an identical grid for every community module.
	 *
	 * @param array<string,mixed> $attributes Component settings.
	 */
	public function section( array $attributes ): string {
		$this->assets();
		$type     = sanitize_key( $attributes['type'] ?? 'teams' );
		if ( 'brands' === $type ) {
			$type                   = 'partners';
			$attributes['category'] = 'brand';
		}
		$number   = max( 1, min( 24, absint( $attributes['number'] ?? 6 ) ) );
		$order    = sanitize_key( $attributes['order'] ?? 'newest' );
		$featured = filter_var( $attributes['featured'] ?? false, FILTER_VALIDATE_BOOL );
		$labels   = array( 'teams' => __( 'Equipas', 'adam-comunidade' ), 'fields' => __( 'Campos', 'adam-comunidade' ), 'partners' => __( 'Parceiros', 'adam-comunidade' ), 'institutions' => __( 'Instituições', 'adam-comunidade' ) );
		if ( ! isset( $labels[ $type ] ) ) {
			return '';
		}
		$items = array();
		if ( 'teams' === $type ) {
			$result = ( new Team_Repository() )->query( array( 'status' => 'published', 'featured' => $featured ? 1 : '', 'orderby' => 'newest' === $order ? 'created_at' : 'name', 'order' => 'alphabetical' === $order ? 'ASC' : 'DESC', 'per_page' => 'random' === $order ? 100 : $number ) );
			if ( 'random' === $order ) {
				shuffle( $result['items'] );
				$result['items'] = array_slice( $result['items'], 0, $number );
			}
			foreach ( $result['items'] as $item ) {
				$items[] = $this->core_card( $item, 'team', Team_Router::team_url( $item ), (int) $item->logo_id );
			}
		} elseif ( 'fields' === $type ) {
			$result = ( new Field_Repository() )->query( array( 'status' => 'published', 'featured' => $featured ? 1 : '', 'orderby' => 'newest' === $order ? 'created_at' : 'name', 'order' => 'alphabetical' === $order ? 'ASC' : 'DESC', 'per_page' => 'random' === $order ? 100 : $number ) );
			if ( 'random' === $order ) {
				shuffle( $result['items'] );
				$result['items'] = array_slice( $result['items'], 0, $number );
			}
			foreach ( $result['items'] as $item ) {
				$items[] = $this->core_card( $item, 'field', Field_Router::field_url( $item ), (int) $item->cover_id );
			}
		} else {
			$singular = array( 'partners' => 'partner', 'institutions' => 'institution' )[ $type ];
			$result   = $this->repository->query( $singular, array( 'status' => 'published', 'category' => sanitize_key( $attributes['category'] ?? '' ), 'featured' => $featured ? 1 : '', 'orderby' => 'alphabetical' === $order ? 'name' : ( 'priority' === $order ? 'priority' : 'created_at' ), 'order' => 'alphabetical' === $order ? 'ASC' : 'DESC', 'per_page' => $number ) );
			if ( 'random' === $order ) {
				$result = $this->repository->query( $singular, array( 'status' => 'published', 'category' => sanitize_key( $attributes['category'] ?? '' ), 'featured' => $featured ? 1 : '', 'per_page' => 100 ) );
				shuffle( $result['items'] );
				$result['items'] = array_slice( $result['items'], 0, $number );
			}
			foreach ( $result['items'] as $item ) {
				$items[] = View::card( $item );
			}
		}
		if ( ! $items ) {
			return '<div class="adam-comunidade__empty">' . esc_html__( 'Ainda não existe conteúdo publicado.', 'adam-comunidade' ) . '</div>';
		}
		return '<section class="adam-community-widget" data-adam-widget="' . esc_attr( $type ) . '"><h2>' . esc_html( $labels[ $type ] ) . '</h2><div class="adam-community-grid">' . implode( '', $items ) . '</div></section>';
	}

	public function highlight( string $type, string $mode, string $category = '' ): string {
		$this->assets();
		$args = array( 'status' => 'published', 'category' => $category, 'per_page' => 'random' === $mode ? 100 : 1 );
		if ( 'featured' === $mode ) {
			$args['homepage_featured'] = 1;
			$args['orderby']           = 'priority';
			$args['order']             = 'DESC';
		} else {
			$args['orderby'] = 'created_at';
			$args['order']   = 'DESC';
		}
		$items = $this->repository->query( $type, $args )['items'];
		if ( 'featured' === $mode && ! $items ) {
			unset( $args['homepage_featured'] );
			$args['featured'] = 1;
			$items = $this->repository->query( $type, $args )['items'];
		}
		if ( 'random' === $mode && $items ) {
			$items = array( $items[ array_rand( $items ) ] );
		}
		return $items ? '<div class="adam-community-highlight" data-adam-widget="' . esc_attr( $mode . '-' . $type ) . '">' . View::card( $items[0] ) . '</div>' : '';
	}

	public function map(): string {
		$this->assets( true );
		return Community_Map::render();
	}

	/** Add the map without rewriting existing editorial blocks. */
	public function community_map_content( string $content ): string {
		if ( is_admin() || ! is_main_query() || ! in_the_loop() || ! \ADAM\Comunidade\Managed_Pages::is_current( 'community' ) ) {
			return $content;
		}
		if ( str_contains( $content, 'data-adam-map=' ) || str_contains( $content, 'data-adam-advanced-map' ) ) {
			return $content;
		}
		$map = $this->map();
		$position = strpos( $content, '<div class="wp-block-group alignfull adam-community-landing__cta' );
		return false === $position ? $content . $map : substr_replace( $content, $map, $position, 0 );
	}

	public function team_connections( object $team ): void {
		echo $this->backlinks( 'team', (int) $team->id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public function field_connections( object $field ): void {
		echo $this->backlinks( 'field', (int) $field->id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	private function backlinks( string $type, int $id ): string {
		$connected = $this->relationships->connected( $type, $id );
		$cards = array();
		foreach ( $connected as $edge ) {
			$source = $edge->target_type === $type && (int) $edge->target_id === $id;
			$other_type = $source ? $edge->source_type : $edge->target_type;
			$other_id   = $source ? (int) $edge->source_id : (int) $edge->target_id;
			if ( Types::get( $other_type ) ) {
				$item = $this->repository->find( $other_id, $other_type );
				if ( $item && 'published' === $item->status ) {
					$cards[] = View::card( $item );
				}
			}
		}
		return $cards ? '<section class="adam-community-section"><h2>' . esc_html__( 'Parceiros da Comunidade', 'adam-comunidade' ) . '</h2><div class="adam-community-grid">' . implode( '', $cards ) . '</div></section>' : '';
	}

	private function core_card( object $item, string $type, string $url, int $image_id ): string {
		$media = 'team' === $type
			? Team_View::logo( $item, array( 'class' => 'adam-community-card__team-logo', 'loading' => 'lazy' ) )
			: ( $image_id
				? wp_get_attachment_image( $image_id, 'medium', false, array( 'loading' => 'lazy' ) )
				: Placeholder_Image::cover( $type, (string) $item->name ) );
		return '<article class="adam-community-card" data-entity-type="' . esc_attr( $type ) . '" data-entity-id="' . esc_attr( (string) $item->id ) . '"><a class="adam-community-card__media" href="' . esc_url( $url ) . '">' . $media . '</a><div class="adam-community-card__body"><span class="adam-community-card__meta">' . esc_html( View::type_label( $type ) ) . '</span><h2><a href="' . esc_url( $url ) . '">' . esc_html( $item->name ) . '</a></h2><p>' . esc_html( $item->short_description ?? '' ) . '</p><a class="adam-community-button" href="' . esc_url( $url ) . '">' . esc_html__( 'Ver detalhes', 'adam-comunidade' ) . '</a></div></article>';
	}

	private function assets( bool $map = false ): void {
		wp_enqueue_style( 'adam-comunidade' );
		wp_enqueue_style( 'adam-comunidade-directory', Helpers::url( 'assets/css/directory-public.css' ), array( 'adam-comunidade' ), ADAM_COMUNIDADE_VERSION );
		if ( $map ) {
			wp_enqueue_style( 'adam-leaflet', Helpers::url( 'assets/vendor/leaflet/leaflet.css' ), array(), '1.9.4' );
			wp_enqueue_script( 'adam-leaflet', Helpers::url( 'assets/vendor/leaflet/leaflet.js' ), array(), '1.9.4', true );
			wp_enqueue_style( 'adam-comunidade-map', Helpers::url( 'assets/css/community-map.css' ), array( 'adam-comunidade-directory', 'adam-leaflet' ), ADAM_COMUNIDADE_VERSION );
			wp_enqueue_script( 'adam-comunidade-map', Helpers::url( 'assets/js/community-map.js' ), array( 'adam-leaflet' ), ADAM_COMUNIDADE_VERSION, true );
			wp_localize_script(
				'adam-comunidade-map',
				'adamCommunityMap',
				array(
					'tileUrl' => apply_filters( 'adam_comunidade_map_tile_url', 'https://tile.openstreetmap.org/{z}/{x}/{y}.png' ),
					'tileAttribution' => apply_filters( 'adam_comunidade_map_tile_attribution', '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' ),
					'closePopup' => __( 'Fechar localização', 'adam-comunidade' ),
					'zoomIn' => __( 'Aproximar', 'adam-comunidade' ),
					'zoomOut' => __( 'Afastar', 'adam-comunidade' ),
					'noResults' => __( 'Nenhuma localização corresponde aos filtros.', 'adam-comunidade' ),
					'count' => __( '%d localizações disponíveis', 'adam-comunidade' ),
					'error' => __( 'Não foi possível carregar o mapa. Consulta as localizações na lista.', 'adam-comunidade' ),
					'tileError' => __( 'O mapa de base está indisponível. Podes continuar a consultar as localizações na lista.', 'adam-comunidade' ),
					'details' => __( 'Ver detalhes', 'adam-comunidade' ),
					'empty'   => __( 'Ainda não existe conteúdo da comunidade com localização disponível.', 'adam-comunidade' ),
					'types'   => array( 'team' => __( 'Equipa', 'adam-comunidade' ), 'field' => __( 'Campo', 'adam-comunidade' ), 'partner' => __( 'Parceiro', 'adam-comunidade' ), 'institution' => __( 'Instituição', 'adam-comunidade' ) ),
				)
			);
		}
	}
}
