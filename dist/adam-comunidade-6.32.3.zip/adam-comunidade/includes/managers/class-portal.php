<?php
/**
 * Front-end Community Manager portal.
 *
 * @package ADAM_Comunidade
 */

namespace ADAM\Comunidade\Managers;

defined( 'ABSPATH' ) || exit;

use ADAM\Comunidade\Config;
use ADAM\Comunidade\Fields\Options as Field_Options;
use ADAM\Comunidade\Fields\Repository as Field_Repository;
use ADAM\Comunidade\Directory\Repository as Directory_Repository;
use ADAM\Comunidade\Helpers;
use ADAM\Comunidade\Managed_Pages;
use ADAM\Comunidade\Public_Hero;
use ADAM\Comunidade\Teams\Options as Team_Options;
use ADAM\Comunidade\Teams\Media_Lifecycle as Team_Media_Lifecycle;
use ADAM\Comunidade\Teams\View as Team_View;
use ADAM\Comunidade\Uploads\Component as Upload_Component;
use ADAM\Comunidade\Uploads\Handler as Upload_Handler;

/**
 * Provides a dedicated, non-WordPress login and management interface.
 */
final class Portal {
	private const ROUTES_VERSION = '1.2.0';
	private static ?self $instance = null;
	private Upload_Handler $uploads;

	public function __construct( private Auth $auth, private Service $service, ?Upload_Handler $uploads = null ) {
		$this->uploads = $uploads ?? new Upload_Handler();
		self::$instance = $this;
	}

	public function register(): void {
		add_action( 'init', array( self::class, 'add_rewrite_rules' ) );
		add_action( 'init', array( self::class, 'maybe_flush_rewrite_rules' ), 999 );
		add_filter( 'query_vars', array( $this, 'query_vars' ) );
		add_filter( 'template_include', array( $this, 'template' ) );
		add_filter( 'document_title_parts', array( $this, 'title' ) );
		add_action( 'template_redirect', array( $this, 'access_control' ), 1 );
		add_action( 'wp_enqueue_scripts', array( $this, 'assets' ) );
		foreach ( array( 'login', 'activate', 'logout', 'revision', 'request_reset', 'reset' ) as $action ) {
			add_action( 'admin_post_nopriv_adam_manager_' . $action, array( $this, 'handle_' . $action ) );
			add_action( 'admin_post_adam_manager_' . $action, array( $this, 'handle_' . $action ) );
		}
	}

	public static function add_rewrite_rules(): void {
		$path = Managed_Pages::path( 'manager' ) ?: 'gestor';
		add_rewrite_rule( '^' . preg_quote( $path, '#' ) . '/editar/(team|field|partner|institution)/([0-9]+)/?$', 'index.php?adam_manager_route=edit&adam_manager_type=$matches[1]&adam_manager_id=$matches[2]', 'top' );
		// Keeps invitation links generated before managed pages existed valid.
		add_rewrite_rule( '^gestor/ativar/([a-f0-9]{64})/?$', 'index.php?adam_manager_route=activate&adam_manager_token=$matches[1]', 'top' );
	}

	public static function maybe_flush_rewrite_rules(): void {
		if ( self::ROUTES_VERSION === get_option( 'adam_comunidade_manager_routes_version' ) ) {
			return;
		}
		flush_rewrite_rules( false );
		update_option( 'adam_comunidade_manager_routes_version', self::ROUTES_VERSION, false );
	}

	public function query_vars( array $vars ): array {
		return array_merge( $vars, array( 'adam_manager_route', 'adam_manager_token', 'adam_manager_type', 'adam_manager_id' ) );
	}

	public function template( string $template ): string {
		return $this->route() ? Helpers::path( 'templates/managers/portal.php' ) : $template;
	}

	public function title( array $parts ): array {
		$route = $this->route();
		if ( $route ) {
			$titles = array(
				'login'    => __( 'Iniciar Sessão', 'adam-comunidade' ),
				'activate' => __( 'Criar Palavra-passe', 'adam-comunidade' ),
				'recovery' => __( 'Recuperar Palavra-passe', 'adam-comunidade' ),
			);
			$parts['title'] = $titles[ $route ] ?? __( 'Área do Gestor', 'adam-comunidade' );
		}
		return $parts;
	}

	public function assets(): void {
		if ( ! $this->route() ) {
			return;
		}
		wp_enqueue_style( 'adam-comunidade' );
		wp_enqueue_script( 'adam-comunidade' );
		Upload_Component::enqueue_assets();
	}

	public static function url(): string {
		return Managed_Pages::url( 'manager' );
	}

	public static function login_url(): string {
		return Managed_Pages::url( 'manager_login' );
	}

	public static function activation_url( string $token ): string {
		return add_query_arg( 'convite', rawurlencode( $token ), Managed_Pages::url( 'manager_activation' ) );
	}

	public static function recovery_url( string $token = '' ): string {
		$url = Managed_Pages::url( 'manager_recovery' );
		return $token ? add_query_arg( 'codigo', rawurlencode( $token ), $url ) : $url;
	}

	public static function edit_url( string $type, int $id ): string {
		return trailingslashit( self::url() ) . 'editar/' . sanitize_key( $type ) . '/' . absint( $id ) . '/';
	}

	public static function render(): void {
		if ( self::$instance ) {
			self::$instance->render_page();
		}
	}

	/**
	 * Keeps authentication pages and the private dashboard strictly separated.
	 */
	public function access_control(): void {
		$route = $this->route();
		if ( ! $route ) {
			return;
		}
		$manager = $this->auth->current();
		if ( 'login' === $route && $manager ) {
			wp_safe_redirect( self::url() );
			exit;
		}
		if ( in_array( $route, array( 'dashboard', 'edit' ), true ) && ! $manager ) {
			wp_safe_redirect( add_query_arg( 'estado', 'session-required', self::login_url() ) );
			exit;
		}
		nocache_headers();
	}

	private function render_page(): void {
		$route        = $this->route();
		$is_auth      = in_array( $route, array( 'login', 'activate', 'recovery' ), true );
		$page_heading = $this->page_heading( $route );
		$manager      = $this->auth->current();
		?>
		<main class="adam-community adam-manager-portal adam-manager-portal--<?php echo esc_attr( $is_auth ? 'auth' : sanitize_html_class( $route ?: 'dashboard' ) ); ?>">
			<section class="adam-manager-shell<?php echo $is_auth ? ' adam-manager-shell--auth' : ''; ?>">
				<p class="screen-reader-text" data-adam-manager-live aria-live="polite"></p>
				<header class="<?php echo esc_attr( Public_Hero::root( 'adam-manager-header', 'dark' ) ); ?>">
					<div class="<?php echo esc_attr( Public_Hero::element( 'content', 'adam-manager-header__content' ) ); ?>">
						<p class="<?php echo esc_attr( Public_Hero::element( 'kicker', 'adam-manager-eyebrow' ) ); ?>"><?php esc_html_e( 'ADAM Comunidade', 'adam-comunidade' ); ?></p>
						<h1 id="adam-manager-page-title" class="<?php echo esc_attr( Public_Hero::element( 'title' ) ); ?>"><?php echo esc_html( $page_heading['title'] ); ?></h1>
						<p class="<?php echo esc_attr( Public_Hero::element( 'subtitle' ) ); ?>"><?php echo esc_html( $page_heading['description'] ); ?></p>
						<?php if ( ( $manager && 'edit' === $route ) || ( ! $manager && 'login' !== $route ) ) : ?>
							<nav class="adam-manager-nav" aria-label="<?php esc_attr_e( 'Navegação do Gestor', 'adam-comunidade' ); ?>">
								<?php if ( $manager ) : ?>
									<a href="<?php echo esc_url( self::url() ); ?>"><?php esc_html_e( 'Área do Gestor', 'adam-comunidade' ); ?></a>
								<?php else : ?>
									<a href="<?php echo esc_url( self::login_url() ); ?>"><?php esc_html_e( 'Iniciar sessão', 'adam-comunidade' ); ?></a>
								<?php endif; ?>
							</nav>
						<?php endif; ?>
					</div>
				</header>
				<div class="adam-manager-content">
					<?php $this->notice(); ?>
					<?php
					if ( 'login' === $route ) {
						$this->login_form();
					} elseif ( 'activate' === $route ) {
						$this->activation_form();
					} elseif ( 'recovery' === $route ) {
						$this->recovery_form();
					} elseif ( 'edit' === $route ) {
						$this->edit_form();
					} else {
						$this->dashboard();
					}
					?>
				</div>
			</section>
		</main>
		<?php
	}

	/**
	 * Provides route-aware Hero copy while preserving one visual component.
	 *
	 * @return array{title:string,description:string}
	 */
	private function page_heading( string $route ): array {
		return match ( $route ) {
			'login' => array(
				'title'       => __( 'Gestor da Comunidade', 'adam-comunidade' ),
				'description' => __( 'Gerir equipas, campos, parceiros e outras organizações da Comunidade ADAM.', 'adam-comunidade' ),
			),
			'activate' => array(
				'title'       => __( 'Criar Palavra-passe', 'adam-comunidade' ),
				'description' => __( 'Defina os dados de acesso da sua conta de Gestor da Comunidade.', 'adam-comunidade' ),
			),
			'recovery' => array(
				'title'       => __( 'Recuperar Palavra-passe', 'adam-comunidade' ),
				'description' => __( 'Recupere o acesso à sua conta de forma segura.', 'adam-comunidade' ),
			),
			'edit' => array(
				'title'       => __( 'Editar Registo', 'adam-comunidade' ),
				'description' => __( 'Prepare uma proposta de alteração para revisão pela ADAM.', 'adam-comunidade' ),
			),
			default => array(
				'title'       => __( 'Gestor da Comunidade', 'adam-comunidade' ),
				'description' => __( 'Atualize os registos que lhe foram atribuídos. Todas as alterações são revistas pela ADAM antes da publicação.', 'adam-comunidade' ),
			),
		};
	}

	private function dashboard(): void {
		$manager = $this->auth->current();
		if ( ! $manager ) {
			echo '<div class="adam-community-empty"><h2>' . esc_html__( 'A sessão terminou.', 'adam-comunidade' ) . '</h2><a class="adam-community-button" href="' . esc_url( self::login_url() ) . '">' . esc_html__( 'Iniciar sessão', 'adam-comunidade' ) . '</a></div>';
			return;
		}
		$assignments = $this->service->assignments( (int) $manager->id );
		$record_names = $this->service->record_names( $assignments );
		$active_revisions = $this->service->active_revisions_for_manager( (int) $manager->id );
		$needs_information = count(
			array_filter(
				$active_revisions,
				static fn( object $revision ): bool => 'needs_info' === (string) $revision->status
			)
		);
		$awaiting_review = count( $active_revisions ) - $needs_information;
		$ready_to_edit   = max( 0, count( $record_names ) - count( $active_revisions ) );
		?>
		<div class="adam-manager-toolbar">
			<p><?php echo esc_html( sprintf( __( 'Sessão iniciada como %s', 'adam-comunidade' ), (string) $manager->email ) ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="adam_manager_logout">
				<input type="hidden" name="adam_manager_csrf" value="<?php echo esc_attr( $this->auth->csrf_token() ); ?>">
				<button class="adam-community-button adam-community-button--secondary" type="submit"><?php esc_html_e( 'Terminar sessão', 'adam-comunidade' ); ?></button>
			</form>
		</div>
		<section class="adam-manager-summary" aria-label="<?php esc_attr_e( 'Resumo dos meus registos', 'adam-comunidade' ); ?>">
			<div><strong><?php echo esc_html( (string) count( $record_names ) ); ?></strong><span><?php esc_html_e( 'Registos atribuídos', 'adam-comunidade' ); ?></span></div>
			<div><strong><?php echo esc_html( (string) $awaiting_review ); ?></strong><span><?php esc_html_e( 'A aguardar a ADAM', 'adam-comunidade' ); ?></span></div>
			<div class="<?php echo $needs_information ? 'has-action' : ''; ?>"><strong><?php echo esc_html( (string) $needs_information ); ?></strong><span><?php esc_html_e( 'Requerem a sua atenção', 'adam-comunidade' ); ?></span></div>
			<div><strong><?php echo esc_html( (string) $ready_to_edit ); ?></strong><span><?php esc_html_e( 'Disponíveis para editar', 'adam-comunidade' ); ?></span></div>
		</section>
		<?php if ( $needs_information ) : ?>
			<div class="adam-manager-next-action" role="status">
				<strong><?php esc_html_e( 'A ADAM pediu alterações.', 'adam-comunidade' ); ?></strong>
				<p><?php echo esc_html( sprintf( _n( 'Abra o registo assinalado e atualize a proposta.', 'Abra os %d registos assinalados e atualize as propostas.', $needs_information, 'adam-comunidade' ), $needs_information ) ); ?></p>
			</div>
		<?php endif; ?>
		<h2><?php esc_html_e( 'Os meus registos', 'adam-comunidade' ); ?></h2>
		<?php if ( ! $record_names ) : ?>
			<div class="adam-community-empty"><h3><?php esc_html_e( 'Ainda não existem registos atribuídos.', 'adam-comunidade' ); ?></h3></div>
		<?php else : ?>
			<div class="adam-manager-list">
				<?php foreach ( $assignments as $assignment ) :
					$revision_key = (string) $assignment->entity_type . ':' . (int) $assignment->entity_id;
					$record_name = $record_names[ $revision_key ] ?? '';
					$active_revision = $active_revisions[ $revision_key ] ?? null;
					?>
					<?php if ( ! $record_name ) { continue; } ?>
					<article class="adam-card adam-manager-card">
						<?php $entity_labels = array( 'field' => __( 'Campo', 'adam-comunidade' ), 'team' => __( 'Equipa', 'adam-comunidade' ), 'partner' => __( 'Parceiro', 'adam-comunidade' ), 'institution' => __( 'Instituição', 'adam-comunidade' ) ); ?>
						<span class="adam-card__eyebrow"><?php echo esc_html( $entity_labels[ $assignment->entity_type ] ?? __( 'Organização', 'adam-comunidade' ) ); ?></span>
						<h3><?php echo esc_html( $record_name ); ?></h3>
						<?php if ( $active_revision ) :
							$is_own_revision = (int) $active_revision->manager_id === (int) $manager->id;
							$status_labels = array(
								'pending'    => __( 'A aguardar revisão', 'adam-comunidade' ),
								'needs_info' => __( 'Alterações necessárias', 'adam-comunidade' ),
								'processing' => __( 'Em análise neste momento', 'adam-comunidade' ),
							);
							?>
							<p><span class="adam-manager-revision-status adam-manager-revision-status--<?php echo esc_attr( (string) $active_revision->status ); ?>"><?php echo esc_html( $status_labels[ $active_revision->status ] ?? __( 'Em revisão', 'adam-comunidade' ) ); ?></span></p>
							<?php if ( 'needs_info' === $active_revision->status && $active_revision->admin_note ) : ?><p><strong><?php esc_html_e( 'Alterações pedidas pela ADAM:', 'adam-comunidade' ); ?></strong><br><?php echo nl2br( esc_html( (string) $active_revision->admin_note ) ); ?></p><?php endif; ?>
							<p><?php echo esc_html( $is_own_revision ? __( 'Pode atualizar a proposta enquanto esta não estiver em análise.', 'adam-comunidade' ) : __( 'Outro Gestor já enviou alterações para esta organização.', 'adam-comunidade' ) ); ?></p>
							<?php if ( $is_own_revision && 'processing' !== $active_revision->status ) : ?><a class="adam-community-button" href="<?php echo esc_url( self::edit_url( (string) $assignment->entity_type, (int) $assignment->entity_id ) ); ?>"><?php esc_html_e( 'Editar proposta pendente', 'adam-comunidade' ); ?></a><?php endif; ?>
						<?php else : ?>
							<p><?php esc_html_e( 'As alterações enviadas ficam pendentes até serem revistas pela administração.', 'adam-comunidade' ); ?></p>
							<a class="adam-community-button" href="<?php echo esc_url( self::edit_url( (string) $assignment->entity_type, (int) $assignment->entity_id ) ); ?>"><?php esc_html_e( 'Editar registo', 'adam-comunidade' ); ?></a>
						<?php endif; ?>
					</article>
				<?php endforeach; ?>
			</div>
		<?php endif;
	}

	private function login_form(): void {
		?>
		<form class="adam-card adam-manager-form adam-manager-login" aria-labelledby="adam-manager-page-title" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="adam_manager_login">
			<?php wp_nonce_field( 'adam_manager_login' ); ?>
			<label><span><?php esc_html_e( 'E-mail', 'adam-comunidade' ); ?></span><input type="email" name="email" autocomplete="email" required></label>
			<label><span><?php esc_html_e( 'Palavra-passe', 'adam-comunidade' ); ?></span><input type="password" name="password" autocomplete="current-password" required></label>
			<button class="adam-community-button" type="submit"><?php esc_html_e( 'Entrar', 'adam-comunidade' ); ?></button>
			<p><a href="<?php echo esc_url( self::recovery_url() ); ?>"><?php esc_html_e( 'Recuperar palavra-passe', 'adam-comunidade' ); ?></a></p>
			<p class="adam-manager-help"><?php esc_html_e( 'A conta de Gestor é independente da sua conta WordPress ou de Sócio ADAM.', 'adam-comunidade' ); ?></p>
		</form>
		<?php
	}

	private function activation_form(): void {
		$token = sanitize_text_field( (string) ( get_query_var( 'adam_manager_token' ) ?: wp_unslash( $_GET['convite'] ?? '' ) ) );
		?>
		<form class="adam-card adam-manager-form adam-manager-login" aria-labelledby="adam-manager-page-title" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="adam_manager_activate">
			<?php wp_nonce_field( 'adam_manager_activate' ); ?>
			<input type="hidden" name="token" value="<?php echo esc_attr( $token ); ?>">
			<p><?php esc_html_e( 'Defina a palavra-passe desta conta. O endereço de e-mail já está associado ao convite.', 'adam-comunidade' ); ?></p>
			<label><span><?php esc_html_e( 'Palavra-passe', 'adam-comunidade' ); ?></span><input type="password" name="password" minlength="10" autocomplete="new-password" required></label>
			<label><span><?php esc_html_e( 'Confirmar palavra-passe', 'adam-comunidade' ); ?></span><input type="password" name="password_confirm" minlength="10" autocomplete="new-password" required></label>
			<button class="adam-community-button" type="submit"><?php esc_html_e( 'Criar conta de Gestor', 'adam-comunidade' ); ?></button>
		</form>
		<?php
	}

	private function recovery_form(): void {
		$token = sanitize_text_field( (string) wp_unslash( $_GET['codigo'] ?? '' ) );
		if ( $token ) {
			?>
			<form class="adam-card adam-manager-form adam-manager-login" aria-labelledby="adam-manager-page-title" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="adam_manager_reset">
				<?php wp_nonce_field( 'adam_manager_reset' ); ?>
				<input type="hidden" name="token" value="<?php echo esc_attr( $token ); ?>">
				<label><span><?php esc_html_e( 'Nova palavra-passe', 'adam-comunidade' ); ?></span><input type="password" name="password" minlength="10" autocomplete="new-password" required></label>
				<label><span><?php esc_html_e( 'Confirmar palavra-passe', 'adam-comunidade' ); ?></span><input type="password" name="password_confirm" minlength="10" autocomplete="new-password" required></label>
				<button class="adam-community-button" type="submit"><?php esc_html_e( 'Guardar nova palavra-passe', 'adam-comunidade' ); ?></button>
			</form>
			<?php
			return;
		}
		?>
		<form class="adam-card adam-manager-form adam-manager-login" aria-labelledby="adam-manager-page-title" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="adam_manager_request_reset">
			<?php wp_nonce_field( 'adam_manager_request_reset' ); ?>
			<p><?php esc_html_e( 'Introduza o e-mail da sua conta de Gestor. Se existir uma conta ativa, receberá um endereço de recuperação.', 'adam-comunidade' ); ?></p>
			<label><span><?php esc_html_e( 'E-mail', 'adam-comunidade' ); ?></span><input type="email" name="email" autocomplete="email" required></label>
			<button class="adam-community-button" type="submit"><?php esc_html_e( 'Enviar recuperação', 'adam-comunidade' ); ?></button>
		</form>
		<?php
	}

	private function edit_form(): void {
		$manager = $this->auth->current();
		if ( ! $manager ) {
			$this->login_form();
			return;
		}
		$type   = sanitize_key( (string) get_query_var( 'adam_manager_type' ) );
		$id     = absint( get_query_var( 'adam_manager_id' ) );
		$record = $this->service->can_manage( (int) $manager->id, $type, $id ) ? $this->service->record( $type, $id ) : null;
		if ( ! $record ) {
			status_header( 403 );
			echo '<div class="adam-community-empty"><h2>' . esc_html__( 'Não tem acesso a este registo.', 'adam-comunidade' ) . '</h2></div>';
			return;
		}
		$active_revision = $this->service->active_revision( $type, $id );
		if ( $active_revision && (int) $active_revision->manager_id !== (int) $manager->id ) {
			echo '<div class="adam-community-empty"><h2>' . esc_html__( 'Já existe uma proposta em revisão.', 'adam-comunidade' ) . '</h2><p>' . esc_html__( 'Outro Gestor enviou alterações para esta organização. Poderá editar novamente depois de a ADAM concluir essa revisão.', 'adam-comunidade' ) . '</p><a class="adam-community-button" href="' . esc_url( self::url() ) . '">' . esc_html__( 'Voltar à Área do Gestor', 'adam-comunidade' ) . '</a></div>';
			return;
		}
		if ( $active_revision && 'processing' === (string) $active_revision->status ) {
			echo '<div class="adam-community-empty"><h2>' . esc_html__( 'A proposta está a ser analisada.', 'adam-comunidade' ) . '</h2><p>' . esc_html__( 'A edição fica temporariamente indisponível enquanto a ADAM conclui a decisão.', 'adam-comunidade' ) . '</p><a class="adam-community-button" href="' . esc_url( self::url() ) . '">' . esc_html__( 'Voltar à Área do Gestor', 'adam-comunidade' ) . '</a></div>';
			return;
		}
		$pending_payload = $active_revision ? $this->service->revision_payload( $active_revision ) : array();
		if ( $pending_payload ) {
			$record = (object) array_merge( (array) $record, $pending_payload );
		}
		$styles = 'field' === $type ? Field_Options::playing_styles() : ( 'team' === $type ? Team_Options::playing_styles() : array() );
		$selected_styles = 'field' === $type ? Field_Options::decode_list( $record->playing_styles ?? '' ) : ( 'team' === $type ? Team_Options::decode_list( $record->playing_styles ?? '' ) : array() );
		$current_gallery_ids = isset( $pending_payload['gallery_ids'] )
			? array_map( 'absint', (array) $pending_payload['gallery_ids'] )
			: ( isset( $pending_payload['gallery'] ) ? array_map( 'absint', (array) $pending_payload['gallery'] ) : $this->gallery_ids( $type, $record ) );
		$image_policy   = Config::upload_policy( 'manager_image' );
		$gallery_policy = Config::upload_policy( 'manager_gallery' );
		$gallery_max    = in_array( $type, array( 'team', 'field' ), true ) ? 5 : $gallery_policy['max_files'];
		$image_accept   = implode( ',', array_map( static fn( string $extension ): string => '.' . $extension, $image_policy['extensions'] ) );
		?>
		<form class="adam-card adam-manager-form" data-adam-manager-editor method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="adam_manager_revision">
			<input type="hidden" name="adam_manager_csrf" value="<?php echo esc_attr( $this->auth->csrf_token() ); ?>">
			<input type="hidden" name="entity_type" value="<?php echo esc_attr( $type ); ?>">
			<input type="hidden" name="entity_id" value="<?php echo esc_attr( (string) $id ); ?>">
			<div class="adam-manager-form__heading"><div><p class="adam-manager-eyebrow"><?php esc_html_e( 'Proposta de alteração', 'adam-comunidade' ); ?></p><h2><?php echo esc_html( (string) $record->name ); ?></h2></div><a href="<?php echo esc_url( self::url() ); ?>"><?php esc_html_e( 'Voltar aos meus registos', 'adam-comunidade' ); ?></a></div>
			<?php if ( $active_revision ) : ?>
				<div class="adam-manager-pending-banner" role="status">
					<strong><?php esc_html_e( 'Está a editar a proposta pendente.', 'adam-comunidade' ); ?></strong>
					<p><?php esc_html_e( 'Ao voltar a enviar, esta versão substitui a proposta anterior no trabalho pendente. A versão anterior permanece no histórico administrativo.', 'adam-comunidade' ); ?></p>
					<?php if ( 'needs_info' === $active_revision->status && $active_revision->admin_note ) : ?><p><strong><?php esc_html_e( 'Alterações pedidas pela ADAM:', 'adam-comunidade' ); ?></strong><br><?php echo nl2br( esc_html( (string) $active_revision->admin_note ) ); ?></p><?php endif; ?>
				</div>
			<?php endif; ?>
			<?php if ( in_array( $type, array( 'field', 'team' ), true ) ) : ?>
				<aside class="adam-public-contact-notice" role="note">
					<strong><?php esc_html_e( 'Redes e contactos públicos', 'adam-comunidade' ); ?></strong>
					<p><?php esc_html_e( 'O Website e os links de WhatsApp, Instagram e Facebook que adicionar abaixo serão apresentados publicamente na página do Campo ou da Equipa. Todos estes campos são opcionais. O email, o telefone e os restantes contactos administrativos não são publicados.', 'adam-comunidade' ); ?></p>
				</aside>
			<?php endif; ?>
			<div class="adam-form-grid">
				<label><span><?php esc_html_e( 'Nome', 'adam-comunidade' ); ?></span><input type="text" name="manager[name]" value="<?php echo esc_attr( (string) $record->name ); ?>" required></label>
				<?php if ( in_array( $type, array( 'team', 'field' ), true ) ) : ?><label><span><?php esc_html_e( 'Concelho', 'adam-comunidade' ); ?></span><input type="text" name="manager[municipality]" value="<?php echo esc_attr( (string) ( $record->municipality ?? '' ) ); ?>"></label><?php endif; ?>
				<label><span><?php esc_html_e( 'Distrito', 'adam-comunidade' ); ?></span><input type="text" name="manager[district]" value="<?php echo esc_attr( (string) ( $record->district ?? '' ) ); ?>"></label>
				<label class="adam-field--wide"><span><?php esc_html_e( 'Morada', 'adam-comunidade' ); ?></span><input type="text" name="manager[address]" value="<?php echo esc_attr( (string) ( $record->address ?? '' ) ); ?>"></label>
				<?php if ( 'field' === $type ) : ?><label class="adam-field--wide"><span><?php esc_html_e( 'Localização do Campo no Google Maps', 'adam-comunidade' ); ?></span><input type="url" name="manager[maps_url]" value="<?php echo esc_attr( (string) ( $record->maps_url ?? '' ) ); ?>"><small><?php esc_html_e( 'Cole o link da localização no Google Maps. Indique de preferência a entrada, estacionamento ou ponto de encontro utilizado pelos jogadores.', 'adam-comunidade' ); ?></small></label><?php endif; ?>
				<label class="adam-field--wide"><span><?php esc_html_e( 'Descrição breve', 'adam-comunidade' ); ?></span><textarea name="manager[short_description]" rows="3"><?php echo esc_textarea( (string) ( $record->short_description ?? '' ) ); ?></textarea></label>
				<label class="adam-field--wide"><span><?php esc_html_e( 'Descrição completa', 'adam-comunidade' ); ?></span><textarea name="manager[full_description]" rows="10"><?php echo esc_textarea( wp_strip_all_tags( (string) ( $record->full_description ?? '' ) ) ); ?></textarea></label>
				<label><span><?php esc_html_e( 'Website', 'adam-comunidade' ); ?></span><input type="url" name="manager[website]" value="<?php echo esc_attr( (string) ( $record->website ?? '' ) ); ?>"><?php if ( in_array( $type, array( 'field', 'team' ), true ) ) : ?><small><?php esc_html_e( 'Opcional.', 'adam-comunidade' ); ?></small><?php endif; ?></label>
				<label><span><?php esc_html_e( 'Facebook', 'adam-comunidade' ); ?></span><input type="url" name="manager[facebook]" value="<?php echo esc_attr( (string) ( $record->facebook ?? '' ) ); ?>"><?php if ( in_array( $type, array( 'field', 'team' ), true ) ) : ?><small><?php esc_html_e( 'Opcional.', 'adam-comunidade' ); ?></small><?php endif; ?></label>
				<label><span><?php esc_html_e( 'Instagram', 'adam-comunidade' ); ?></span><input type="url" name="manager[instagram]" value="<?php echo esc_attr( (string) ( $record->instagram ?? '' ) ); ?>"><?php if ( in_array( $type, array( 'field', 'team' ), true ) ) : ?><small><?php esc_html_e( 'Opcional.', 'adam-comunidade' ); ?></small><?php endif; ?></label>
				<?php if ( in_array( $type, array( 'field', 'team' ), true ) ) : ?><label><span><?php esc_html_e( 'WhatsApp', 'adam-comunidade' ); ?></span><input type="url" name="manager[whatsapp]" value="<?php echo esc_attr( (string) ( $record->whatsapp ?? '' ) ); ?>"><small><?php esc_html_e( 'Opcional.', 'adam-comunidade' ); ?></small></label><?php endif; ?>
				<label><span><?php esc_html_e( 'E-mail de contacto interno', 'adam-comunidade' ); ?></span><input type="email" name="manager[email]" value="<?php echo esc_attr( (string) ( $record->email ?? '' ) ); ?>"></label>
				<label><span><?php esc_html_e( 'Telefone de contacto interno', 'adam-comunidade' ); ?></span><input type="tel" name="manager[phone]" value="<?php echo esc_attr( (string) ( $record->phone ?? '' ) ); ?>"></label>
			</div>
			<?php if ( $styles ) : ?><fieldset class="adam-manager-choices"><legend><?php esc_html_e( 'Estilos de jogo', 'adam-comunidade' ); ?></legend><?php foreach ( $styles as $key => $label ) : ?><label><input type="checkbox" name="manager[playing_styles][]" value="<?php echo esc_attr( $key ); ?>" <?php checked( in_array( $key, $selected_styles, true ) ); ?>> <?php echo esc_html( $label ); ?></label><?php endforeach; ?></fieldset><?php endif; ?>
			<?php if ( 'field' === $type ) { $this->field_sections( $record, $pending_payload ); } elseif ( 'team' === $type ) { $this->team_sections( $record ); } else { $this->directory_sections( $record ); } ?>
			<div class="adam-manager-media">
				<h3><?php esc_html_e( 'Imagens', 'adam-comunidade' ); ?></h3>
				<input type="hidden" name="gallery_reviewed" value="1">
				<?php if ( ! empty( $record->cover_id ) && wp_attachment_is_image( (int) $record->cover_id ) ) : ?><div class="adam-manager-current-image"><strong><?php esc_html_e( 'Capa incluída na proposta', 'adam-comunidade' ); ?></strong><?php echo wp_get_attachment_image( (int) $record->cover_id, 'thumbnail' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><label><input type="checkbox" name="remove_cover" value="1"> <?php esc_html_e( 'Propor remoção da capa', 'adam-comunidade' ); ?></label></div><?php endif; ?>
				<label><?php esc_html_e( 'Nova imagem de capa (opcional)', 'adam-comunidade' ); ?></label>
				<?php Upload_Component::render( array( 'mode' => 'file', 'kind' => 'image', 'name' => 'manager_cover', 'accept' => $image_accept, 'max_size_mb' => $image_policy['max_size_mb'] ) ); ?>
				<?php if ( 'field' !== $type && ! empty( $record->logo_id ) && wp_attachment_is_image( (int) $record->logo_id ) ) : ?><div class="adam-manager-current-image adam-manager-current-image--logo"><strong><?php esc_html_e( 'Logótipo incluído na proposta', 'adam-comunidade' ); ?></strong><?php echo Team_View::logo( $record, array( 'class' => 'adam-manager-current-image__logo' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><label><input type="checkbox" name="remove_logo" value="1"> <?php esc_html_e( 'Propor remoção do logótipo', 'adam-comunidade' ); ?></label></div><?php endif; ?>
				<?php if ( 'field' !== $type ) : ?><label><?php esc_html_e( 'Novo logótipo (opcional)', 'adam-comunidade' ); ?></label><?php Upload_Component::render( array( 'mode' => 'file', 'kind' => 'image', 'name' => 'manager_logo', 'class' => 'adam-upload--team-logo', 'accept' => $image_accept, 'max_size_mb' => $image_policy['max_size_mb'] ) ); ?><?php endif; ?>
				<label><?php esc_html_e( 'Fotografias da galeria (opcional)', 'adam-comunidade' ); ?></label>
				<?php $gallery_items = array_map( static fn( int $attachment_id ): array => Upload_Component::attachment( $attachment_id ), array_slice( $current_gallery_ids, 0, $gallery_max ) ); ?>
				<?php Upload_Component::render( array( 'mode' => 'file', 'kind' => 'image', 'name' => 'manager_gallery[]', 'accept' => implode( ',', array_map( static fn( string $extension ): string => '.' . $extension, $gallery_policy['extensions'] ) ), 'multiple' => true, 'max' => $gallery_max, 'items' => $gallery_items, 'existing_name' => 'keep_gallery_ids[]', 'order_name' => 'gallery_order[]', 'max_size_mb' => $gallery_policy['max_size_mb'] ) ); ?>
			</div>
			<div class="adam-manager-submit-bar">
				<div>
					<strong data-adam-save-state><?php esc_html_e( 'Nenhuma alteração por enviar', 'adam-comunidade' ); ?></strong>
					<p class="adam-manager-review-note"><?php esc_html_e( 'O registo público só será atualizado depois da revisão pela ADAM.', 'adam-comunidade' ); ?></p>
				</div>
				<button class="adam-community-button" type="submit"><?php esc_html_e( 'Enviar alterações para revisão', 'adam-comunidade' ); ?></button>
			</div>
		</form>
		<?php
	}

	private function field_sections( object $record, array $pending_payload = array() ): void {
		$repo = new Field_Repository();
		$selected = isset( $pending_payload['amenity_ids'] )
			? array_map( 'absint', (array) $pending_payload['amenity_ids'] )
			: $repo->amenity_ids( (int) $record->id );
		?>
		<div class="adam-form-grid">
			<label><span><?php esc_html_e( 'Jogadores recomendados', 'adam-comunidade' ); ?></span><input type="number" min="0" name="manager[recommended_players]" value="<?php echo esc_attr( (string) $record->recommended_players ); ?>"></label>
			<label><span><?php esc_html_e( 'Máximo de jogadores', 'adam-comunidade' ); ?></span><input type="number" min="0" name="manager[max_players]" value="<?php echo esc_attr( (string) $record->max_players ); ?>"></label>
			<label class="adam-field--wide"><span><?php esc_html_e( 'Regras', 'adam-comunidade' ); ?></span><textarea name="manager[rules]" rows="8"><?php echo esc_textarea( wp_strip_all_tags( (string) $record->rules ) ); ?></textarea></label>
			<label class="adam-field--wide"><span><?php esc_html_e( 'Funcionamento', 'adam-comunidade' ); ?></span><textarea name="manager[opening_hours]" rows="6" placeholder="<?php esc_attr_e( 'Ex.: Jogos normalmente aos domingos, em datas anunciadas previamente nas nossas redes sociais.', 'adam-comunidade' ); ?>"><?php echo esc_textarea( (string) ( $record->opening_hours ?? '' ) ); ?></textarea><small><?php esc_html_e( 'Indica quando costumam realizar-se jogos ou como são anunciadas as datas. Não é necessário indicar um horário fixo.', 'adam-comunidade' ); ?></small></label>
		</div>
		<fieldset class="adam-manager-choices"><legend><?php esc_html_e( 'Comodidades', 'adam-comunidade' ); ?></legend><?php
		global $wpdb;
		$amenities = $wpdb->get_results( 'SELECT id,label FROM ' . \ADAM\Comunidade\Fields\Schema::amenities_table() . " WHERE status = 'active' ORDER BY sort_order,label" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		foreach ( $amenities as $amenity ) : ?><label><input type="checkbox" name="amenity_ids[]" value="<?php echo esc_attr( (string) $amenity->id ); ?>" <?php checked( in_array( (int) $amenity->id, $selected, true ) ); ?>> <?php echo esc_html( (string) $amenity->label ); ?></label><?php endforeach; ?></fieldset>
		<?php
	}

	private function team_sections( object $record ): void {
		$recruitment_status = Team_Options::normalize_recruitment_status( $record->recruitment_status ?? '' );
		?>
		<div class="adam-form-grid">
			<label><span><?php esc_html_e( 'Nome abreviado', 'adam-comunidade' ); ?></span><input type="text" name="manager[short_name]" value="<?php echo esc_attr( (string) $record->short_name ); ?>"></label>
			<label><span><?php esc_html_e( 'Ano de fundação', 'adam-comunidade' ); ?></span><input type="number" min="1800" max="<?php echo esc_attr( gmdate( 'Y' ) ); ?>" name="manager[founded]" value="<?php echo esc_attr( (string) $record->founded ); ?>"></label>
			<label><span><?php esc_html_e( 'Número de elementos', 'adam-comunidade' ); ?></span><input type="number" min="0" name="manager[members]" value="<?php echo esc_attr( (string) $record->members ); ?>"></label>
			<label><span><?php esc_html_e( 'Estado do recrutamento', 'adam-comunidade' ); ?></span><select name="manager[recruitment_status]"><option value="" <?php selected( $recruitment_status, '' ); ?>><?php esc_html_e( 'Não indicado', 'adam-comunidade' ); ?></option><?php foreach ( Team_Options::recruitment_statuses() as $key => $label ) : ?><option value="<?php echo esc_attr( $key ); ?>" <?php selected( $recruitment_status, $key ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label>
			<label class="adam-field--wide"><span><?php esc_html_e( 'Requisitos de experiência', 'adam-comunidade' ); ?></span><textarea name="manager[recruitment_experience]"><?php echo esc_textarea( (string) $record->recruitment_experience ); ?></textarea></label>
			<label class="adam-field--wide"><span><?php esc_html_e( 'Equipamento obrigatório', 'adam-comunidade' ); ?></span><textarea name="manager[recruitment_equipment]"><?php echo esc_textarea( (string) $record->recruitment_equipment ); ?></textarea></label>
		</div>
		<?php
	}

	private function directory_sections( object $record ): void {
		?>
		<div class="adam-form-grid">
			<label><span><?php esc_html_e( 'Categoria', 'adam-comunidade' ); ?></span><input type="text" name="manager[category]" value="<?php echo esc_attr( (string) ( $record->category ?? '' ) ); ?>"></label>
			<label><span><?php esc_html_e( 'País', 'adam-comunidade' ); ?></span><input type="text" name="manager[country]" value="<?php echo esc_attr( (string) ( $record->country ?? '' ) ); ?>"></label>
			<label class="adam-field--wide"><span><?php esc_html_e( 'Benefícios', 'adam-comunidade' ); ?></span><textarea name="manager[benefits]" rows="6"><?php echo esc_textarea( wp_strip_all_tags( (string) ( $record->benefits ?? '' ) ) ); ?></textarea></label>
			<label class="adam-field--wide"><span><?php esc_html_e( 'Benefícios para Sócios ADAM', 'adam-comunidade' ); ?></span><textarea name="manager[member_benefits]" rows="6"><?php echo esc_textarea( wp_strip_all_tags( (string) ( $record->member_benefits ?? '' ) ) ); ?></textarea></label>
		</div>
		<?php
	}

	public function handle_login(): never {
		check_admin_referer( 'adam_manager_login' );
		$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
		$key   = 'adam_manager_login_' . md5( strtolower( $email ) . '|' . (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) );
		$attempts = absint( get_transient( $key ) );
		$security = Config::manager_security();
		if ( $attempts >= $security['login_attempt_limit'] || ! $this->auth->login( $email, (string) wp_unslash( $_POST['password'] ?? '' ) ) ) {
			set_transient( $key, $attempts + 1, $security['login_lockout_ttl'] );
			$this->redirect_login_status( 'login-failed' );
		}
		delete_transient( $key );
		$this->redirect_status( 'logged-in' );
	}

	public function handle_activate(): never {
		check_admin_referer( 'adam_manager_activate' );
		$password = (string) wp_unslash( $_POST['password'] ?? '' );
		$token    = sanitize_text_field( wp_unslash( $_POST['token'] ?? '' ) );
		if ( ! hash_equals( $password, (string) wp_unslash( $_POST['password_confirm'] ?? '' ) ) ) {
			wp_safe_redirect( add_query_arg( 'estado', 'password-mismatch', self::activation_url( $token ) ) );
			exit;
		}
		$result = $this->service->activate( $token, $password );
		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( 'estado', 'activation-failed', self::activation_url( $token ) ) );
			exit;
		}
		$this->redirect_login_status( 'activated' );
	}

	public function handle_request_reset(): never {
		check_admin_referer( 'adam_manager_request_reset' );
		$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
		$key = 'adam_manager_reset_' . md5( strtolower( $email ) . '|' . (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) );
		$security = Config::manager_security();
		if ( absint( get_transient( $key ) ) < $security['reset_request_limit'] ) {
			$this->service->request_password_reset( $email );
			set_transient( $key, absint( get_transient( $key ) ) + 1, $security['reset_rate_window'] );
		}
		wp_safe_redirect( add_query_arg( 'estado', 'reset-requested', self::recovery_url() ) );
		exit;
	}

	public function handle_reset(): never {
		check_admin_referer( 'adam_manager_reset' );
		$password = (string) wp_unslash( $_POST['password'] ?? '' );
		$token    = sanitize_text_field( wp_unslash( $_POST['token'] ?? '' ) );
		if ( ! hash_equals( $password, (string) wp_unslash( $_POST['password_confirm'] ?? '' ) ) ) {
			wp_safe_redirect( add_query_arg( 'estado', 'password-mismatch', self::recovery_url( $token ) ) );
			exit;
		}
		$result = $this->service->reset_password( $token, $password );
		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( 'estado', 'reset-failed', self::recovery_url( $token ) ) );
			exit;
		}
		$this->redirect_login_status( 'password-reset' );
	}

	public function handle_logout(): never {
		if ( ! $this->auth->verify_csrf( $_POST['adam_manager_csrf'] ?? '' ) ) {
			wp_die( esc_html__( 'O pedido de segurança expirou.', 'adam-comunidade' ), 403 );
		}
		$this->auth->logout();
		$this->redirect_login_status( 'logged-out' );
	}

	public function handle_revision(): never {
		$manager = $this->auth->current();
		if ( ! $manager || ! $this->auth->verify_csrf( $_POST['adam_manager_csrf'] ?? '' ) ) {
			wp_die( esc_html__( 'A sessão expirou. Inicie sessão novamente.', 'adam-comunidade' ), 403 );
		}
		$type  = sanitize_key( wp_unslash( $_POST['entity_type'] ?? '' ) );
		$id    = absint( $_POST['entity_id'] ?? 0 );
		if ( ! $this->service->can_manage( (int) $manager->id, $type, $id ) ) {
			wp_die( esc_html__( 'Não tem acesso a este registo.', 'adam-comunidade' ), 403 );
		}
		$active_revision = $this->service->active_revision( $type, $id );
		$pending_payload = $active_revision && (int) $active_revision->manager_id === (int) $manager->id
			? $this->service->revision_payload( $active_revision )
			: array();
		$input = isset( $_POST['manager'] ) && is_array( $_POST['manager'] ) ? wp_unslash( $_POST['manager'] ) : array();
		// Media IDs are accepted only from uploads processed in this request.
		unset( $input['cover_id'], $input['logo_id'], $input['gallery'] );
		if ( isset( $pending_payload['cover_id'] ) ) {
			$input['cover_id'] = absint( $pending_payload['cover_id'] );
		}
		if ( isset( $pending_payload['logo_id'] ) ) {
			$input['logo_id'] = absint( $pending_payload['logo_id'] );
		}
		if ( ! empty( $_POST['remove_cover'] ) ) {
			$input['cover_id'] = 0;
		}
		if ( 'field' !== $type && ! empty( $_POST['remove_logo'] ) ) {
			$input['logo_id'] = 0;
		}
		$uploaded = array();
		$image_policy = Config::upload_policy( 'manager_image' );
		$cover = $this->uploads->upload_one( 'manager_cover', $image_policy['extensions'], $image_policy['max_size_mb'] );
		if ( is_wp_error( $cover ) ) { wp_die( esc_html( $cover->get_error_message() ) ); }
		if ( $cover ) { $input['cover_id'] = $cover; $uploaded[] = $cover; }
		if ( 'field' !== $type ) {
			$logo = $this->uploads->upload_one( 'manager_logo', $image_policy['extensions'], $image_policy['max_size_mb'] );
			if ( is_wp_error( $logo ) ) {
				$this->uploads->delete( $uploaded );
				wp_die( esc_html( $logo->get_error_message() ) );
			}
			if ( $logo ) { $input['logo_id'] = $logo; $uploaded[] = $logo; }
		}
		$gallery_policy = Config::upload_policy( 'manager_gallery' );
		$gallery_max = in_array( $type, array( 'team', 'field' ), true ) ? 5 : $gallery_policy['max_files'];
		$gallery = $this->uploads->upload_many(
			'manager_gallery',
			$gallery_policy['extensions'],
			$gallery_max,
			$gallery_policy['max_size_mb']
		);
		if ( is_wp_error( $gallery ) ) {
			$this->uploads->delete( $uploaded );
			wp_die( esc_html( $gallery->get_error_message() ) );
		}
		$uploaded = array_merge( $uploaded, $gallery );
		$current_record = $this->service->record( $type, $id );
		$current_gallery_ids = isset( $pending_payload['gallery_ids'] )
			? array_map( 'absint', (array) $pending_payload['gallery_ids'] )
			: ( isset( $pending_payload['gallery'] ) ? array_map( 'absint', (array) $pending_payload['gallery'] ) : ( $current_record ? $this->gallery_ids( $type, $current_record ) : array() ) );
		$kept_gallery_ids = array_values(
			array_intersect(
				$current_gallery_ids,
				array_filter( array_map( 'absint', (array) wp_unslash( $_POST['keep_gallery_ids'] ?? array() ) ) )
			)
		);
		$gallery_order = isset( $_POST['gallery_order'] ) && is_array( $_POST['gallery_order'] )
			? array_map( 'sanitize_text_field', wp_unslash( $_POST['gallery_order'] ) )
			: array();
		$next_gallery_ids = array();
		$new_index        = 0;
		foreach ( $gallery_order as $token ) {
			if ( str_starts_with( $token, 'existing:' ) ) {
				$attachment_id = absint( substr( $token, 9 ) );
				if ( in_array( $attachment_id, $kept_gallery_ids, true ) ) {
					$next_gallery_ids[] = $attachment_id;
				}
			} elseif ( 'new' === $token && isset( $gallery[ $new_index ] ) ) {
				$next_gallery_ids[] = absint( $gallery[ $new_index ] );
				++$new_index;
			}
		}
		$next_gallery_ids = array_values( array_unique( array_merge( $next_gallery_ids, $kept_gallery_ids, array_slice( $gallery, $new_index ) ) ) );
		if ( count( $next_gallery_ids ) > $gallery_max ) {
			$this->uploads->delete( $uploaded );
			wp_die( esc_html__( 'A galeria pode ter no máximo 5 imagens. Remova uma imagem existente antes de adicionar outra.', 'adam-comunidade' ) );
		}
		if ( 'team' === $type ) {
			Team_Media_Lifecycle::claim( $id, $uploaded );
		}
		$relations = array();
		if ( isset( $_POST['gallery_reviewed'] ) ) {
			if ( 'team' === $type ) { $input['gallery'] = $next_gallery_ids; } else { $relations['gallery_ids'] = $next_gallery_ids; }
		}
		if ( 'field' === $type ) {
			$relations['amenity_ids'] = isset( $_POST['amenity_ids'] ) ? wp_unslash( $_POST['amenity_ids'] ) : array();
		}
		$result = $this->service->submit_revision( (int) $manager->id, $type, $id, $input, $relations );
		if ( is_wp_error( $result ) ) {
			$this->uploads->delete( $uploaded );
			wp_die( esc_html( $result->get_error_message() ) );
		}
		$this->redirect_status( 'revision-sent' );
	}

	private function gallery_ids( string $type, object $record ): array {
		if ( 'field' === $type ) {
			return array_values(
				array_filter(
					array_map(
						static fn( object $item ): int => absint( $item->attachment_id ?? 0 ),
						( new Field_Repository() )->gallery( (int) $record->id )
					),
					'wp_attachment_is_image'
				)
			);
		}
		if ( in_array( $type, array( 'partner', 'institution' ), true ) ) {
			return array_values(
				array_filter(
					array_map(
						static fn( object $item ): int => absint( $item->attachment_id ?? 0 ),
						( new Directory_Repository() )->gallery( (int) $record->id )
					),
					'wp_attachment_is_image'
				)
			);
		}
		return array_values(
			array_filter(
				array_map( 'absint', (array) json_decode( (string) ( $record->gallery ?? '[]' ), true ) ),
				'wp_attachment_is_image'
			)
		);
	}

	private function notice(): void {
		$status = sanitize_key( wp_unslash( $_GET['estado'] ?? '' ) );
		$messages = array(
			'session-required'  => __( 'Inicie sessão para aceder à Área do Gestor.', 'adam-comunidade' ),
			'login-failed'      => __( 'Não foi possível iniciar sessão. Verifique os dados e tente novamente.', 'adam-comunidade' ),
			'logged-in'         => __( 'Sessão iniciada com sucesso.', 'adam-comunidade' ),
			'logged-out'        => __( 'Sessão terminada.', 'adam-comunidade' ),
			'password-mismatch' => __( 'As palavras-passe não coincidem.', 'adam-comunidade' ),
			'activation-failed' => __( 'O convite é inválido, já foi utilizado ou expirou.', 'adam-comunidade' ),
			'activated'         => __( 'Conta criada. Já pode iniciar sessão.', 'adam-comunidade' ),
			'revision-sent'     => __( 'Alterações enviadas para revisão. O registo público mantém-se inalterado até à aprovação.', 'adam-comunidade' ),
			'reset-requested'   => __( 'Se existir uma conta ativa com esse e-mail, enviámos as instruções de recuperação.', 'adam-comunidade' ),
			'reset-failed'      => __( 'O pedido de recuperação é inválido, já foi utilizado ou expirou.', 'adam-comunidade' ),
			'password-reset'    => __( 'Palavra-passe atualizada. Já pode iniciar sessão.', 'adam-comunidade' ),
		);
		if ( isset( $messages[ $status ] ) ) {
			echo '<div class="adam-manager-notice" role="status">' . esc_html( $messages[ $status ] ) . '</div>';
		}
	}

	private function redirect_status( string $status ): never {
		wp_safe_redirect( add_query_arg( 'estado', $status, self::url() ) );
		exit;
	}

	private function redirect_login_status( string $status ): never {
		wp_safe_redirect( add_query_arg( 'estado', $status, self::login_url() ) );
		exit;
	}

	private function route(): string {
		$route = sanitize_key( (string) get_query_var( 'adam_manager_route' ) );
		if ( $route ) {
			return $route;
		}
		if ( Managed_Pages::is_current( 'manager_activation' ) ) {
			return 'activate';
		}
		if ( Managed_Pages::is_current( 'manager_login' ) ) {
			return 'login';
		}
		if ( Managed_Pages::is_current( 'manager_recovery' ) ) {
			return 'recovery';
		}
		return Managed_Pages::is_current( 'manager' ) ? 'dashboard' : '';
	}
}
