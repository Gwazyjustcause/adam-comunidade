<?php
/**
 * Directory presentation helpers.
 *
 * @package ADAM_Comunidade
 */

namespace ADAM\Comunidade\Directory;

defined( 'ABSPATH' ) || exit;

use ADAM\Comunidade\Placeholder_Image;
use ADAM\Comunidade\Public_Privacy;

/**
 * Renders reusable public fragments.
 */
final class View {
	public static function card( object $entry ): string {
		$definition = Types::get( $entry->entity_type );
		if ( ! $definition ) {
			return '';
		}
		ob_start();
		?>
		<article class="adam-community-card" data-entity-type="<?php echo esc_attr( $entry->entity_type ); ?>" data-entity-id="<?php echo esc_attr( $entry->id ); ?>">
			<a class="adam-community-card__media" href="<?php echo esc_url( Router::entry_url( $entry ) ); ?>">
				<?php if ( $entry->logo_id ) : ?>
					<?php echo wp_get_attachment_image( (int) $entry->logo_id, 'adam-directory-logo', false, array( 'loading' => 'lazy' ) ); ?>
				<?php elseif ( $entry->cover_id ) : ?>
					<?php echo wp_get_attachment_image( (int) $entry->cover_id, 'adam-directory-card', false, array( 'loading' => 'lazy' ) ); ?>
				<?php else : ?>
					<?php echo Placeholder_Image::cover( (string) $entry->entity_type, (string) $entry->name ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php endif; ?>
			</a>
			<div class="adam-community-card__body">
				<?php if ( $entry->featured ) : ?><span class="adam-community-badge"><?php esc_html_e( 'Em destaque', 'adam-comunidade' ); ?></span><?php endif; ?>
				<?php if ( $entry->verification ) : ?><span class="adam-community-badge adam-badge--verified"><?php echo esc_html( self::verification_label( (string) $entry->verification ) ); ?></span><?php endif; ?>
				<h2><a href="<?php echo esc_url( Router::entry_url( $entry ) ); ?>"><?php echo esc_html( $entry->name ); ?></a></h2>
				<?php if ( $entry->category && isset( $definition['categories'][ $entry->category ] ) ) : ?><p class="adam-community-card__meta"><?php echo esc_html( $definition['categories'][ $entry->category ] ); ?></p><?php endif; ?>
				<?php if ( $entry->short_description ) : ?><p><?php echo esc_html( $entry->short_description ); ?></p><?php endif; ?>
				<div class="adam-community-card__actions">
					<a class="adam-community-button" href="<?php echo esc_url( Router::entry_url( $entry ) ); ?>"><?php esc_html_e( 'Ver detalhes', 'adam-comunidade' ); ?></a>
					<?php if ( $entry->website ) : ?><a class="adam-community-button adam-community-button--ghost" href="<?php echo esc_url( $entry->website ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Visitar página Web', 'adam-comunidade' ); ?></a><?php endif; ?>
				</div>
			</div>
		</article>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Renders AJAX buttons or progressively enhanced pagination links.
	 *
	 * @param int                 $page       Current page.
	 * @param int                 $pages      Total pages.
	 * @param array<string,mixed> $query_args Query arguments for non-JavaScript links.
	 */
	public static function pagination( int $page, int $pages, array $query_args = array() ): string {
		if ( $pages <= 1 ) {
			return '';
		}
		$output = '<nav class="adam-community-pagination" aria-label="' . esc_attr__( 'Páginas do diretório', 'adam-comunidade' ) . '">';
		for ( $number = 1; $number <= $pages; $number++ ) {
			if ( $query_args ) {
				$query_args['pagina'] = $number;
				$output .= '<a href="' . esc_url( add_query_arg( $query_args, get_permalink() ) ) . '" data-page="' . esc_attr( (string) $number ) . '"'
					. ( $number === $page ? ' aria-current="page"' : '' ) . '>' . esc_html( (string) $number ) . '</a>';
			} else {
				$output .= '<button type="button" data-page="' . esc_attr( (string) $number ) . '"'
					. ( $number === $page ? ' aria-current="page"' : '' ) . '>' . esc_html( (string) $number ) . '</button>';
			}
		}
		return $output . '</nav>';
	}

	public static function verification_label( string $status ): string {
		return array(
			'verified'             => __( 'Verificado', 'adam-comunidade' ),
			'verified_partner'     => __( 'Parceiro verificado', 'adam-comunidade' ),
			'verified_institution' => __( 'Instituição verificada', 'adam-comunidade' ),
			'verified_brand'       => __( 'Marca verificada', 'adam-comunidade' ),
			'official_partner'     => __( 'Parceiro oficial', 'adam-comunidade' ),
			'adam_partner'         => __( 'Parceiro ADAM', 'adam-comunidade' ),
			'institutional_partner'=> __( 'Parceiro institucional', 'adam-comunidade' ),
		)[ $status ] ?? __( 'Verificado', 'adam-comunidade' );
	}

	public static function type_label( string $type ): string {
		if ( 'field' === $type ) {
			return __( 'Campo', 'adam-comunidade' );
		}
		if ( 'team' === $type ) {
			return __( 'Equipa', 'adam-comunidade' );
		}
		$definition = Types::get( $type );
		return $definition ? (string) $definition['singular'] : __( 'Entidade', 'adam-comunidade' );
	}

	public static function public_links( object $entry ): string {
		$labels = array(
			'website'   => array( '🌍', __( 'Página Web', 'adam-comunidade' ) ),
			'facebook'  => array( 'f', 'Facebook' ),
			'instagram' => array( '◎', 'Instagram' ),
			'discord'   => array( 'D', 'Discord' ),
			'youtube'   => array( '▶', 'YouTube' ),
			'tiktok'    => array( '♪', 'TikTok' ),
			'linkedin'  => array( 'in', 'LinkedIn' ),
		);
		ob_start();
		foreach ( Public_Privacy::public_links( $entry ) as $key => $url ) {
			$label = $labels[ $key ] ?? array( '↗', ucfirst( $key ) );
			printf( '<a class="adam-contact-button" href="%1$s" target="_blank" rel="noopener"><span aria-hidden="true">%2$s</span>%3$s</a>', esc_url( $url ), esc_html( $label[0] ), esc_html( $label[1] ) );
		}
		return (string) ob_get_clean();
	}
}
