<?php
/**
 * Automatic district landing page.
 *
 * @package ADAM_Comunidade
 */

defined( 'ABSPATH' ) || exit;

use ADAM\Comunidade\Directory\Repository as Directory_Repository;
use ADAM\Comunidade\Directory\View as Directory_View;
use ADAM\Comunidade\Experience\Builder;
use ADAM\Comunidade\Experience\Discovery;
use ADAM\Comunidade\Experience\Smart_Blocks;
use ADAM\Comunidade\Fields\Repository as Field_Repository;
use ADAM\Comunidade\Fields\View as Field_View;
use ADAM\Comunidade\Teams\Repository as Team_Repository;
use ADAM\Comunidade\Teams\View as Team_View;
use ADAM\Comunidade\Public_Hero;
use ADAM\Comunidade\Events\Api as Events_Api;

$region_slug = sanitize_title( (string) get_query_var( 'adam_region' ) );
$district = \ADAM\Comunidade\Experience\Router::regions()[ $region_slug ] ?? ucwords( str_replace( '-', ' ', $region_slug ) );
$teams_repo = new Team_Repository();
$fields_repo = new Field_Repository();
$directory_repo = new Directory_Repository();
$discovery = new Discovery( $teams_repo, $fields_repo, $directory_repo );
$teams = $teams_repo->query( array( 'status' => 'published', 'district' => $district, 'per_page' => 6 ) )['items'];
$recruiting_teams = $teams_repo->query( array( 'status' => 'published', 'district' => $district, 'recruitment' => 'recruiting', 'per_page' => 6 ) )['items'];
$fields = $fields_repo->query( array( 'status' => 'published', 'district' => $district, 'per_page' => 6 ) )['items'];
$featured_fields = $fields_repo->query( array( 'status' => 'published', 'district' => $district, 'featured' => 1, 'per_page' => 3 ) )['items'];
$partners = $directory_repo->query( 'partner', array( 'status' => 'published', 'district' => $district, 'per_page' => 6 ) )['items'];
$institutions = $directory_repo->query( 'institution', array( 'status' => 'published', 'district' => $district, 'per_page' => 6 ) )['items'];
$markers = $discovery->map_records( array( 'district' => $district ) );
$upcoming_events = function_exists( 'adam_comunidade_events' ) ? Events_Api::instance()->upcoming_events( 3 ) : array();
$section = static fn( string $title, array $cards ): string => $cards ? '<section class="adam-community-widget"><h2>' . esc_html( $title ) . '</h2><div class="adam-community-grid">' . implode( '', $cards ) . '</div></section>' : '';

get_header();
?>
<main class="adam-experience" id="main">
	<header class="<?php echo esc_attr( Public_Hero::root( 'adam-experience-hero', 'archive' ) ); ?>"><div class="<?php echo esc_attr( Public_Hero::element( 'content', 'adam-experience-container' ) ); ?>"><span class="<?php echo esc_attr( Public_Hero::element( 'kicker' ) ); ?>"><?php esc_html_e( 'Região', 'adam-comunidade' ); ?></span><h1 class="<?php echo esc_attr( Public_Hero::element( 'title' ) ); ?>"><?php echo esc_html( $district ); ?></h1><p class="<?php echo esc_attr( Public_Hero::element( 'subtitle' ) ); ?>"><?php echo esc_html( sprintf( __( 'A comunidade ADAM em %s.', 'adam-comunidade' ), $district ) ); ?></p></div></header>
	<div class="adam-experience-container">
		<?php echo ( new Smart_Blocks( $discovery ) )->statistics( $district ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<section class="adam-advanced-map" data-adam-advanced-map data-markers="<?php echo esc_attr( wp_json_encode( $markers ) ); ?>"><div class="adam-section-title"><h2><?php esc_html_e( 'Mapa da região', 'adam-comunidade' ); ?></h2></div><div class="adam-map-layout"><div class="adam-map-canvas" data-adam-map-canvas role="region" aria-label="<?php esc_attr_e( 'Mapa da região', 'adam-comunidade' ); ?>"></div><div class="adam-map-results" data-adam-map-results></div></div></section>
		<?php echo $section( __( 'Equipas', 'adam-comunidade' ), array_map( array( Team_View::class, 'card' ), $teams ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php echo $section( __( 'Equipas a recrutar', 'adam-comunidade' ), array_map( array( Team_View::class, 'card' ), $recruiting_teams ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php echo $section( __( 'Campos', 'adam-comunidade' ), array_map( static fn( object $item ): string => Field_View::card( $item, $fields_repo ), $fields ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php echo $section( __( 'Campos em destaque', 'adam-comunidade' ), array_map( static fn( object $item ): string => Field_View::card( $item, $fields_repo ), $featured_fields ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php echo $section( __( 'Parceiros', 'adam-comunidade' ), array_map( array( Directory_View::class, 'card' ), $partners ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php echo $section( __( 'Instituições', 'adam-comunidade' ), array_map( array( Directory_View::class, 'card' ), $institutions ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php echo Builder::news_cards( 4 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<section class="adam-community-widget">
			<h2><?php esc_html_e( 'Próximos eventos', 'adam-comunidade' ); ?></h2>
			<?php if ( $upcoming_events ) : ?>
				<div class="adam-community-grid">
					<?php foreach ( $upcoming_events as $event ) : ?>
						<article class="adam-event-card"><div>
							<time datetime="<?php echo esc_attr( $event->event_date() ); ?>"><?php echo esc_html( wp_date( 'j \d\e F', $event->starts_at_timestamp() ) ); ?></time>
							<h3><a href="<?php echo esc_url( Events_Api::instance()->event_url( $event ) ); ?>"><?php echo esc_html( $event->title() ); ?></a></h3>
							<?php if ( $event->location() ) : ?><p><?php echo esc_html( $event->location() ); ?></p><?php endif; ?>
						</div></article>
					<?php endforeach; ?>
				</div>
			<?php else : ?>
				<div class="adam-comunidade__empty"><?php esc_html_e( 'Ainda não existem eventos agendados.', 'adam-comunidade' ); ?></div>
			<?php endif; ?>
		</section>
	</div>
</main>
<?php get_footer(); ?>
